"""CodeAlpha Task 3: Extract unique email addresses from a text file."""
import re
from pathlib import Path

INPUT_FILE = "sample_emails.txt"
OUTPUT_FILE = "extracted_emails.txt"
EMAIL_PATTERN = r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"


def extract_emails(input_file):
    text = Path(input_file).read_text(encoding="utf-8")
    matches = re.findall(EMAIL_PATTERN, text)
    unique, seen = [], set()
    for address in matches:
        key = address.lower()
        if key not in seen:
            seen.add(key)
            unique.append(address)
    return unique


def save_emails(emails, output_file):
    content = "\\n".join(emails)
    Path(output_file).write_text(content + ("\\n" if content else ""), encoding="utf-8")


def main():
    print("===== EMAIL ADDRESS EXTRACTOR =====")
    input_file = input(f"Input filename (Enter for {INPUT_FILE}): ").strip() or INPUT_FILE
    output_file = input(f"Output filename (Enter for {OUTPUT_FILE}): ").strip() or OUTPUT_FILE
    try:
        emails = extract_emails(input_file)
        save_emails(emails, output_file)
        print(f"\\nUnique email addresses found: {len(emails)}")
        for address in emails:
            print("-", address)
        print(f"\\nResults saved to: {output_file}")
    except FileNotFoundError:
        print(f"Error: Could not find '{input_file}'. Check the filename and try again.")
    except OSError as error:
        print(f"File error: {error}")


if __name__ == "__main__":
    main()
