# CodeAlpha Task Automation — Email Address Extractor

## Internship Task 3 — Python Programming

### Overview
This script reads a text file, finds email addresses with a regular expression, removes duplicate addresses (case-insensitively), and saves the unique results to another text file.

### Features
- Reads a `.txt` input file
- Finds common email address patterns using `re.findall()`
- Removes duplicate addresses
- Saves one address per line to an output file
- Handles missing input files
- Allows custom input and output filenames

### Concepts used
Python `re`, `pathlib`, file handling, lists, sets, functions, loops, conditionals, and exception handling.

### Requirements
Python 3.8 or later. No external packages are needed.

### Run
Keep `extract_emails.py` and `sample_emails.txt` in the same folder, then run:

```bash
python extract_emails.py
```

Press Enter at both prompts to use the default filenames. Results are written to `extracted_emails.txt`.

### Expected sample result
The supplied sample contains three unique example addresses. See `sample_extracted_emails.txt`.

**Note:** `.example` is a reserved example domain. The supplied addresses are placeholders, not real contacts. This is a learning demonstration, not a live email harvesting tool.

### Project structure
```text
CodeAlpha_TaskAutomation/
├── extract_emails.py
├── sample_emails.txt
├── sample_extracted_emails.txt
├── README.md
├── VIDEO_SCRIPT.txt
├── LINKEDIN_POST.txt
└── SUBMISSION_CHECKLIST.txt
```
